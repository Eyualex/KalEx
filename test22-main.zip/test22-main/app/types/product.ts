export interface Product {
  title: string
  images: string
  price: string
  quantity?: number
}
