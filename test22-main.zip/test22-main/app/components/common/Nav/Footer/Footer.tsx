import React from 'react'

function Footer() {
  return (
    <div>
        <div className='flex'>
            <div>
                <h1>E-commerce</h1>
            </div>
            <div className='grid'>
                <h1>Home</h1>
                <h1>About</h1>
                <h1>Contact</h1>
                <h1></h1>
            </div>
        </div>
    </div>
  )
}

export default Footer